var canvas, ctx, precanvas, prectx, gameState;
var g,i;
function onload() {
    canvas = document.getElementById("displaycanvas");
    ctx = canvas.getContext("2d");
    precanvas = document.getElementById("drawcanvas");
    prectx = precanvas.getContext("2d");
    gameState = new StateStack();
    g = new M20();
    }
    
//function gameLoop() {
//    ctx.clearRect(0,0,1000,1000);
//    gameState.update();
//    gameState.draw();
//    frameRate.draw();
//    ctx.drawImage(precanvas,0,0,1000,1000);
//    window.requestAnimationFrame(gameLoop);
//}
class M20 {
    constructor(gamestate) {
        this.i = 5;
        this.frameRate = null;
        this.audio = null;
        this.images = null;
        this.frameRate = null;
        this.gameLoop();
    }
    gameLoop(gamestate) {
        this.i++;
        ctx.clearRect(0,0,1000,1000);
        gameState.update();
        gameState.draw();
        if (this.frameRate)
            this.frameRate.draw();
        ctx.drawImage(precanvas,0,0,1000,1000);
        ctx.fillStyle = "red";
        ctx.fillRect(0,50,this.i,50);
       // console.log(this.i);
        requestAnimationFrame(() => {this.gameLoop();});
    }
    audioModule() {
        var module = document.createElement("script");
        module.src = "/Resources/Js/Audio.js";
        document.head.appendChild(module);
        return new AudioManager();
    };
    imagesModule() {
        var module = document.createElement("script");
        module.src = "/Resources/Js/ImageHandler.js";
        document.head.appendChild(module);
        return new ImageHandler();
    };
    frameRateMonitorModule() {
        var module = document.createElement("script");
        module.src = "/Resources/Js/FrameRateMonitor.js";
        document.head.appendChild(module);
        this.frameRate = new FrameRateMonitor(prectx);
    };
    activateModule(name) {
        var module = document.createElement("script");
        var type;
        var getUrl = window.location;
        var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        switch (name)
        {
            case "audio":
                console.log("Audio Module Requested.");
                module.type = "text/javascript";
                module.src = baseUrl+"/Resources/Js/Audio.js";
                module.onload = () => {
                    console.log("a Loaded");
                    this[name] = new AudioManager();
        console.log(this[name]);
                };
               // document.getElementsByTagName('head')[0].appendChild(module);
                document.head.insertBefore(module, document.head.firstChild);
                break;
            case "images":
                
                break;
            case "frameRate":
                module.src = "/Resources/Js/FrameRateMonitor.js";
                this[name] = new FrameRateMonitor(prectx);
                break;
        }
        
    };
}
document.addEventListener('click',function(){console.log("L");},true);
function foo() {
    g.activateModule("audio");
}
