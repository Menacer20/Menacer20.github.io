class ParticleSystem {
    constructor()
}